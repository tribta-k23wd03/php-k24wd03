function welcome() {
    return <h1 style={{ color: 'purple', fontFamily: 'intel one mono' }}>Welcome to my Laravel Application number 01.</h1>;
}

export default welcome;
